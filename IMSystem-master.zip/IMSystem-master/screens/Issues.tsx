import { View } from "react-native";

export const Issues = () => {
  return <View></View>;
};
