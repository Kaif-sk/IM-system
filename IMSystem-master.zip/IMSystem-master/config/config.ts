const firebaseConfig = {
  apiKey: "AIzaSyDXvVC9n9vGzGQxRgULWQl4dqlUPMcohgI",
  authDomain: "imsystem-9523d.firebaseapp.com",
  databaseURL: "https://imsystem-9523d-default-rtdb.firebaseio.com",
  projectId: "imsystem-9523d",
  storageBucket: "imsystem-9523d.appspot.com",
  messagingSenderId: "928007119571",
  appId: "1:928007119571:web:c009f1757f88bcb65eea26",
};
